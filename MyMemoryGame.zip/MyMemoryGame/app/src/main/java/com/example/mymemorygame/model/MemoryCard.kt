package com.example.mymemorygame.model

data class MemoryCard (
    val identifier : Int ,
    var isFacedUp : Boolean = false,
    var isMatched : Boolean = false
)